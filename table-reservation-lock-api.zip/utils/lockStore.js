const locks = {};

function isLocked(tableId) {
    const lock = locks[tableId];
    if (!lock) return false;

    const currentTime = Date.now();
    if (lock.expiry < currentTime) {
        delete locks[tableId];
        return false;
    }

    return true;
}

function lockTable(tableId, userId, duration) {
    const expiry = Date.now() + duration * 1000;
    locks[tableId] = { userId, expiry };
}

function unlockTable(tableId, userId) {
    if (locks[tableId] && locks[tableId].userId === userId) {
        delete locks[tableId];
        return true;
    }
    return false;
}

function getLockStatus(tableId) {
    return isLocked(tableId);
}

module.exports = { isLocked, lockTable, unlockTable, getLockStatus };
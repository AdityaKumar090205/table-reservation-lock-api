const { isLocked, lockTable, unlockTable, getLockStatus } = require('../utils/lockStore');

exports.lock = (req, res) => {
    const { tableId, userId, duration } = req.body;
    if (isLocked(tableId)) {
        return res.status(409).json({ success: false, message: "Table is currently locked by another user." });
    }
    lockTable(tableId, userId, duration);
    res.status(200).json({ success: true, message: "Table locked successfully." });
};

exports.unlock = (req, res) => {
    const { tableId, userId } = req.body;
    const success = unlockTable(tableId, userId);
    res.status(200).json({ success });
};

exports.status = (req, res) => {
    const { tableId } = req.params;
    const isLockedNow = getLockStatus(tableId);
    res.status(200).json({ isLocked: isLockedNow });
};